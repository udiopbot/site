// Cleaned tractor database (static, Supabase removed)
// Exports 'tractors' array used by the app.
// Images are imported from /src/assets

import mf1035Di from "@/assets/mf-1035-di.jpg";
import mf241Di from "@/assets/mf-241-di.jpg";
import mf245Di from "@/assets/mf-245-di-50hp.jpg";
import mf5118 from "@/assets/mf-5118-2wd.jpg";
import mf5118Enhanced from "@/assets/mf-5118-enhanced.jpg";
import mf30Orchard from "@/assets/mf-30-orchard.jpg";
import dynatrackSmart from "@/assets/dynatrack-smart.jpg";
import dynatrackHeritage from "@/assets/dynatrack-heritage.jpg";
import heroTractor from "@/assets/hero-tractor.jpg";

export const tractors = [
  {
    id: "mf-1035-di",
    model: "Massey Ferguson 1035 DI",
    hp: "36 HP",
    engine: "3-cylinder, 2400 CC, 2500 RPM",
    transmission: "Sliding mesh gearbox, 6 forward + 2 reverse gears, single clutch",
    pto: "540 RPM @ 1500 ERPM, ~30 HP PTO power",
    hydraulics: "Lifting capacity 1100 kg, Draft/Position control",
    brakesSteering: "Dry disc brakes / optional oil-immersed brakes, Mechanical or power steering (optional)",
    tyres: "Front – 6.00 x 16, Rear – 12.4 x 28 / 13.6 x 28",
    fuelTank: "47 L",
    weightWheelbase: "1713 kg approx., 1835 mm wheelbase",
    bestFor: "Agriculture, haulage, threshers, rotavators, and small-scale implements",
    image: mf1035Di,
    popular: true
  },
  {
    id: "mf-1035-dost",
    model: "Massey Ferguson 1035 DI Dost",
    hp: "35 HP",
    engine: "3-cylinder, 2400 CC, 2500 RPM",
    transmission: "8 forward + 2 reverse gears, dual/single clutch",
    pto: "540 RPM, ~30 HP PTO power",
    hydraulics: "Lifting capacity 1100 kg with advanced hydraulics",
    brakesSteering: "Dry disc brakes / optional oil-immersed brakes, Manual steering (power steering optional)",
    tyres: "Front – 6.00 x 16, Rear – 12.4 x 28",
    fuelTank: "47 L",
    weightWheelbase: "1700+ kg, compact body suitable for orchards and small farms",
    bestFor: "Orchard farming, inter-cultivation, small haulage",
    image: mf1035Di,
    popular: false
  },
  {
    id: "mf-1035-superplus",
    model: "Massey Ferguson 1035 DI Super Plus",
    hp: "40 HP",
    engine: "3-cylinder, 2400 CC, 2500 RPM",
    transmission: "8 forward + 2 reverse gears, partial constant mesh gearbox",
    pto: "540 RPM PTO, 34 HP PTO power",
    hydraulics: "Lifting capacity 1100 kg, draft/position control, oil-immersed pumps",
    brakesSteering: "Oil-immersed brakes, mechanical / optional power steering",
    tyres: "Front – 6.00 x 16, Rear – 13.6 x 28",
    fuelTank: "47 L",
    weightWheelbase: "1700+ kg, 1935 mm wheelbase",
    bestFor: "Rotavators, cultivators, ploughs, haulage, and medium-scale farming",
    image: mf1035Di,
    popular: true
  },
  {
    id: "mf-1035-r",
    model: "MF 1035 R",
    hp: "Approx. 31 HP",
    engine: "3-cylinder diesel",
    transmission: "12-speed gearbox",
    drive: "2WD or 4WD",
    steering: "Power steering",
    hydraulics: "Open center system, pump flow ~22.7 L/min",
    liftingCapacity: "1010 kg",
    pto: "Live, 540 RPM",
    weight: "Approx. 1230–1330 kg",
    wheelbase: "1700 mm",
    bestFor: "Compact yet robust, suited for light field work, mowing, and loader duties",
    image: mf1035Di,
    popular: false
  },
  {
    id: "mf-245-di-50",
    model: "MF 245 DI - 50 HP",
    hp: "50 HP",
    engine: "SIMPSONS SJ327 TIII A, 3-cyl, 2700 CC",
    transmission: "Dual clutch; sliding mesh with optional partial constant mesh; 8F+2R or 10F+2R",
    brakes: "Sealed dry disc or multi-disc oil-immersed",
    steering: "Manual with optional power steering",
    hydraulics: "1,700 kg lifting capacity",
    fuelTank: "47 L (variants may have 55 L)",
    tyres: "Front – 6.00 × 16; Rear – 13.6 × 28 or 14.9 × 28",
    performance: "Top speed ~34.2 km/h",
    weight: "Approx. 1915 kg",
    wheelbase: "1830 mm",
    dimensions: "Width ~1705 mm; Length ~3320 mm",
    bestFor: "Heavy-duty farming—ploughing, haulage, implement work",
    image: mf245Di,
    popular: true
  },
  {
    id: "mf-245-pd-46",
    model: "MF 245 PD 46 HP",
    hp: "46 HP",
    engine: "~2700 CC, 3-cylinder",
    transmission: "Partial constant mesh; 8F + 2R or optional 10F + 2R",
    liftingCapacity: "1,700 kg",
    ptoPower: "~42.5 HP",
    fuelTank: "Approx. 55 L",
    steering: "Manual; power steering optional",
    drive: "2WD",
    bestFor: "Versatile mid-range farming tasks—cultivation, ploughing, and general use",
    image: mf245Di,
    popular: false
  },
  {
    id: "mf-241-pd",
    model: "Massey Ferguson 241 PD",
    hp: "42 HP",
    engine: "3-cylinder, 2500 CC, 1900 RPM",
    transmission: "Sliding mesh / partial constant mesh, dual clutch option, 8F + 2R",
    pto: "36 HP PTO, Live PTO with 540 RPM @ 1500 engine RPM",
    hydraulics: "Lifting capacity 1700 kg, draft/position/response control",
    brakesSteering: "Oil-immersed disc brakes, manual / power steering option",
    tyres: "Front – 6.00x16, Rear – 13.6x28 / 12.4x28",
    fuelTank: "47 L",
    weightWheelbase: "Approx. 1875 kg, wheelbase 1785 mm, ground clearance 340 mm",
    bestFor: "Agriculture, haulage, implements like rotavator, cultivator, trailer",
    image: mf241Di,
    popular: true
  },
  {
    id: "mf-241-pd-4wd",
    model: "Massey Ferguson 241 PD 4WD",
    hp: "42 HP",
    engine: "3-cylinder, 2500 CC, 1900 RPM",
    transmission: "Sliding mesh / partial constant mesh, dual clutch, 8F + 2R gears",
    pto: "36 HP PTO, Live PTO with 540 RPM",
    hydraulics: "Lifting capacity 1700 kg, draft/position/response control",
    brakesSteering: "Oil-immersed brakes, power steering standard",
    tyres: "Front – 8.00x18, Rear – 13.6x28 (with 4WD capability)",
    fuelTank: "47 L",
    weightWheelbase: "Approx. 2050 kg, wheelbase 1935 mm, ground clearance 340 mm",
    bestFor: "Orchard farming, wetland cultivation, loader work, and heavy-duty field tasks",
    image: mf241Di,
    popular: false
  },
  {
    id: "mf-241-r",
    model: "Massey Ferguson 241 R",
    hp: "42 HP",
    engine: "3-cylinder, 2500 CC, 1900 RPM",
    transmission: "Sliding mesh, dual clutch option, 8F + 2R gears",
    pto: "36 HP PTO, 540 RPM @ 1500 engine RPM",
    hydraulics: "Lifting capacity 1700 kg, draft/position/response control",
    brakesSteering: "Dry disc / oil-immersed brakes, manual / power steering option",
    tyres: "Front – 6.00x16, Rear – 13.6x28",
    fuelTank: "47 L",
    weightWheelbase: "Approx. 1875 kg, wheelbase 1785 mm, ground clearance 345 mm",
    bestFor: "Agricultural farming, haulage, seeding, and lightweight commercial use",
    image: mf241Di,
    popular: false
  },
  {
    id: "mf-241-orchard-plus",
    model: "MF 241 Orchard Plus",
    hp: "42 HP",
    engine: "3-cylinder, 2500 CC, 2100 RPM",
    transmission: "Sliding mesh, dual clutch, 8F + 2R gears",
    ptoHydraulics: "38 HP PTO, 1700 kg lifting capacity, 540 PTO RPM",
    brakesSteering: "Oil-immersed brakes, mechanical/Power steering (optional)",
    tyres: "Front 6.00 x 16, Rear 12.4 x 28; compact design for orchards",
    fuelTank: "47 L",
    bestFor: "Orchard farming, vineyards, inter-cultivation",
    image: mf241Di,
    popular: false
  },
  {
    id: "mf-30-orchard-plus",
    model: "MF 30 DI Orchard Plus",
    hp: "30 HP",
    engine: "2-cylinder, 1670 CC, 2000 RPM",
    transmission: "Sliding mesh, dual clutch, 6F + 2R gears",
    ptoHydraulics: "25 HP PTO, 1100 kg lifting capacity, 540 PTO RPM",
    brakesSteering: "Oil-immersed brakes, mechanical steering",
    tyres: "Front 5.2 x 14, Rear 12.4 x 24; narrow design for orchards",
    fuelTank: "47 L",
    bestFor: "Small orchards, vineyards, inter-row cultivation",
    image: mf30Orchard,
    popular: false
  },
  {
    id: "dynatrack-smart",
    model: "DynaTrack Smart",
    hp: "Approx. 50 HP",
    engine: "3-cylinder, 2700 CC, inline fuel injection pump",
    transmission: "Fully constant mesh, 12 F + 12 R gears, dual diaphragm/clutch, SuperShuttle",
    pto: "Quadra PTO, six-splined, 540 RPM @ ~1789–1790 ERPM",
    hydraulics: "2050 kg lifting capacity; draft, position & response controls; Cat I linkage",
    brakesSteering: "Maxx oil-immersed brakes; power steering",
    tyresDimensions: "Front 6.00 × 16; Rear 14.9 × 28 or 13.6 × 28; weight ~2190 kg; wheelbase 2040 mm; ground clearance ~400 mm",
    fuelTank: "~61 L",
    bestFor: "Heavy-duty field operations, haulage, puddling, and demanding usage",
    image: dynatrackSmart,
    popular: true
  },
  {
    id: "dynatrack-heritage",
    model: "DynaTrack Heritage Look",
    hp: "Variant/styling variant",
    engine: "Similar DynaTrack platform",
    notes: "Special Heritage styling with modern DynaTrack mechanics",
    image: dynatrackHeritage,
    popular: false
  }
];

export default tractors;
