import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, Mail, Search, Wrench, Tractor, Wheat, Star } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

// Import implement images
import loaderImage from "@/assets/mf-loader.jpg";
import seederImage from "@/assets/super-seeder.jpg";
import tillerImage from "@/assets/rotary-tiller.jpg";
import harrowImage from "@/assets/disc-harrow.jpg";
import trailerImage from "@/assets/hydraulic-trailer.jpg";
import cultivatorImage from "@/assets/cultivator.jpg";
import thresherImage from "@/assets/thresher.jpg";
import planterImage from "@/assets/potato-planter.jpg";

const Implements = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedCompatibility, setSelectedCompatibility] = useState("");

  const equipmentList = [
    {
      id: 1,
      name: "MF 241 DynaTrack Loader",
      category: "Loaders",
      compatibility: "40-50 HP Tractors",
      image: loaderImage,
      features: ["Loader Capacity ~1,100 kg", "Dump Height ~11 ft (335 cm)", "Designed for DynaTrack platform", "Easy attachment and maintenance"],
      applications: ["Material Handling", "Loader operations", "Haulage"],
      specifications: {
        liftingCapacity: "1100 kg",
        maxDumpHeight: "335 cm (approx. 11 ft)",
        recommendedTractorRange: "40-50 HP"
      },
      priceRange: "Contact for Price",
      description: "Loader built specifically for DynaTrack tractors — ideal for material handling and efficient loading operations.",
      popular: true
    },
    {
      id: 2,
      name: "MF 7235 Loader",
      category: "Loaders",
      compatibility: "30-40 HP Tractors",
      image: loaderImage,
      features: ["Hydraulic Control", "High Lifting Capacity (~1,200 kg)", "Easy Attachment", "Durable Build"],
      applications: ["Loader tasks", "Haulage", "Tilling support"],
      specifications: {
        liftingCapacity: "1200 kg",
        bucketCapacity: "0.5 cubic meters (varies by bucket)",
        weight: "Approx. 600-800 kg (depends on configuration)"
      },
      priceRange: "Contact for Price",
      description: "Loader option for MF 7235 family — perfect for loader operations, farm loading and material handling.",
      popular: true
    },
    {
      id: 3,
      name: "TAFE AgriStar Super Seeder",
      category: "Seeders",
      compatibility: "45-90 HP Tractors",
      image: seederImage,
      features: ["3-in-1: Tilling, Sowing & Mulching", "Robust gearbox & bearings", "Powder-coated durable finish"],
      applications: ["Seedbed preparation", "Residue management", "Direct sowing/zero tillage"],
      specifications: {
        requiredTractorHP: "45-90 HP",
        workingWidth: "Model dependent (typically 4-8 ft)"
      },
      priceRange: "Contact for Price",
      description: "Performs seedbed preparation, residue management and sowing in a single pass — ideal for increasing efficiency and reducing stubble burning.",
      popular: false
    },
    {
      id: 4,
      name: "Trailers (Utility)",
      category: "Trailers",
      compatibility: "Varies (match to tractor capacity)",
      image: trailerImage,
      features: ["Heavy-duty chassis", "High payload options", "Easy hitch compatibility"],
      applications: ["Material transport", "Produce haulage", "General farm use"],
      specifications: {
        typicalCapacity: "1-5 tonnes (model-dependent)"
      },
      priceRange: "Contact for Price",
      description: "General purpose utility trailers for haulage and transport; capacity and dimensions depend on model.",
      popular: false
    },
    {
      id: 5,
      name: "Rotavators (Multiple sizes)",
      category: "Rotavators",
      compatibility: "20-60 HP Tractors (model dependent)",
      image: tillerImage,
      features: ["Tough steel construction", "Multiple widths from 3 ft to 10 ft", "High blade counts for effective mixing"],
      applications: ["Seedbed preparation", "Soil mixing", "Residue incorporation"],
      specifications: {
        example6ftBlades: "Approx. 42 blades on 6 ft model",
        sizes: "3 ft - 10 ft available"
      },
      priceRange: "Contact for Price",
      description: "Rotavators available in multiple sizes — ideal for seedbed prep and soil mixing.",
      popular: false
    }
  ];

  const filteredImplements = equipmentList.filter(implement => {
    const matchesSearch = implement.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         implement.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || selectedCategory === "all" || implement.category === selectedCategory;
    const matchesCompatibility = !selectedCompatibility || selectedCompatibility === "all" || 
                                implement.compatibility.includes(selectedCompatibility);
    return matchesSearch && matchesCategory && matchesCompatibility;
  });

  const handleCall = () => {
    window.open('tel:+917895327351');
  };

  const handleWhatsApp = (implement: any) => {
    const message = `Hi, I'm interested in ${implement.name}. Please share more details and pricing.`;
    window.open(`https://wa.me/917895327351?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleEmail = (implement: any) => {
    const subject = `Enquiry for ${implement.name}`;
    const body = `Hi,\n\nI am interested in ${implement.name}.\n\nPlease share:\n- Best price\n- Compatibility with my tractor\n- Delivery timeline\n- Available offers\n\nThank you`;
    window.open(`mailto:doonmotors.tractortafe@gmail.com?subject=${subject}&body=${encodeURIComponent(body)}`);
  };

  return (
    <>
      {/* SEO Meta Tags */}
      <title>Tractor Implements & Attachments | Doon Motors Uttarakhand</title>
      <meta name="description" content="Complete range of tractor implements - loaders, seeders, tillers, harrows at Doon Motors. Compatible with Massey Ferguson tractors. Best prices in Uttarakhand." />
      <meta name="keywords" content="tractor implements Uttarakhand, MF 241 loader, super seeder, rotary tiller, disc harrow, potato planter, tractor attachments Dehradun" />
      <meta property="og:title" content="Best Tractor Implements & Attachments in Uttarakhand | Doon Motors" />
      <meta property="og:description" content="Wide range of quality tractor implements compatible with Massey Ferguson tractors. Expert advice and best prices." />

      <div className="min-h-screen bg-background">
        <Header />
        
        <main>
          {/* Hero Section */}
          <section className="relative bg-gradient-to-br from-primary/10 via-background to-secondary/20 py-12 md:py-20">
            <div className="container mx-auto px-4">
              <div className="text-center mb-8">
                <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
                  Tractor Implements & Attachments
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-6">
                  Complete range of high-quality implements and attachments compatible with 
                  Massey Ferguson tractors. Enhance your farming efficiency with the right tools.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Button size="lg" onClick={handleCall} className="w-full sm:w-auto">
                    <Phone className="mr-2 h-5 w-5" />
                    Call: +91 78953 27351
                  </Button>
                  <Button size="lg" variant="outline" onClick={() => window.open('https://wa.me/917895327351', '_blank')} className="w-full sm:w-auto">
                    <Wrench className="mr-2 h-5 w-5" />
                    Get Implement Quote
                  </Button>
                </div>
              </div>

              {/* Categories Overview */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="bg-white/50 dark:bg-black/20 rounded-lg p-4">
                  <Tractor className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-lg font-bold text-primary">8+</div>
                  <div className="text-sm text-muted-foreground">Implement Types</div>
                </div>
                <div className="bg-white/50 dark:bg-black/20 rounded-lg p-4">
                  <Wrench className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-lg font-bold text-primary">100%</div>
                  <div className="text-sm text-muted-foreground">MF Compatible</div>
                </div>
                <div className="bg-white/50 dark:bg-black/20 rounded-lg p-4">
                  <Star className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-lg font-bold text-primary">15+</div>
                  <div className="text-sm text-muted-foreground">Years Experience</div>
                </div>
                <div className="bg-white/50 dark:bg-black/20 rounded-lg p-4">
                  <Wheat className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-lg font-bold text-primary">24/7</div>
                  <div className="text-sm text-muted-foreground">Support</div>
                </div>
              </div>
            </div>
          </section>

          {/* Filters Section */}
          <section className="py-8 bg-secondary/30">
            <div className="container mx-auto px-4">
              <div className="flex flex-col md:flex-row gap-4 items-center">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search implements (e.g., loader, seeder, tiller)..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent className="z-50 bg-popover">
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="Loaders">Loaders</SelectItem>
                    <SelectItem value="Seeders">Seeders</SelectItem>
                    <SelectItem value="Tillers">Tillers</SelectItem>
                    <SelectItem value="Harrows">Harrows</SelectItem>
                    <SelectItem value="Trailers">Trailers</SelectItem>
                    <SelectItem value="Cultivators">Cultivators</SelectItem>
                    <SelectItem value="Threshers">Threshers</SelectItem>
                    <SelectItem value="Planters">Planters</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedCompatibility} onValueChange={setSelectedCompatibility}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="HP Range" />
                  </SelectTrigger>
                  <SelectContent className="z-50 bg-popover">
                    <SelectItem value="all">All HP</SelectItem>
                    <SelectItem value="35">35-45 HP</SelectItem>
                    <SelectItem value="40">40-50 HP</SelectItem>
                    <SelectItem value="45">45-55 HP</SelectItem>
                    <SelectItem value="50">50-65 HP</SelectItem>
                    <SelectItem value="60">60-75 HP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </section>

          {/* Implements Grid */}
          <section className="py-12">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredImplements.map((implement) => (
                  <Card key={implement.id} className="overflow-hidden hover:shadow-xl transition-all duration-300">
                    {implement.popular && (
                      <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground text-center py-2 text-sm font-medium">
                        <Star className="inline mr-1 h-4 w-4" />
                        Popular Choice
                      </div>
                    )}
                    
                    <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 relative overflow-hidden">
                      <img 
                        src={implement.image} 
                        alt={`${implement.name} - ${implement.category} for tractors`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-accent text-accent-foreground">
                          {implement.category}
                        </Badge>
                      </div>
                    </div>

                    <CardHeader className="pb-3">
                      <CardTitle className="text-xl font-bold text-foreground">
                        {implement.name}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">{implement.description}</p>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {/* Compatibility */}
                      <div className="bg-primary/10 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-1">
                          <Tractor className="h-4 w-4 text-primary" />
                          <span className="text-sm font-semibold">Compatible with:</span>
                        </div>
                        <span className="text-sm">{implement.compatibility}</span>
                      </div>

                      {/* Key Features */}
                      <div>
                        <h4 className="text-sm font-semibold text-foreground mb-2">Key Features:</h4>
                        <div className="flex flex-wrap gap-1">
                          {implement.features.slice(0, 3).map((feature, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                          {implement.features.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{implement.features.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      {/* Applications */}
                      <div>
                        <h4 className="text-sm font-semibold text-foreground mb-2">Applications:</h4>
                        <div className="text-xs text-muted-foreground">
                          {implement.applications.join(", ")}
                        </div>
                      </div>

                      {/* Key Specifications */}
                      <div className="grid grid-cols-2 gap-2 text-xs bg-secondary/20 rounded-lg p-2">
                        {Object.entries(implement.specifications).slice(0, 2).map(([key, value]) => (
                          <div key={key}>
                            <div className="text-muted-foreground capitalize">
                              {key.replace(/([A-Z])/g, ' $1').trim()}:
                            </div>
                            <div className="font-medium">{value}</div>
                          </div>
                        ))}
                      </div>

                      {/* Price Range */}
                      <div className="bg-gradient-to-r from-primary/10 to-primary/20 rounded-lg p-3 text-center">
                        <p className="text-sm font-semibold text-primary mb-1">
                          Contact for Best Price
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Call us for competitive pricing and special offers
                        </p>
                      </div>

                      {/* Action Buttons */}
                      <div className="grid grid-cols-2 gap-2">
                        <Button 
                          size="sm" 
                          className="text-xs"
                          onClick={handleCall}
                        >
                          <Phone className="mr-1 h-3 w-3" />
                          Call Now
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="text-xs"
                          onClick={() => handleWhatsApp(implement)}
                        >
                          WhatsApp
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {filteredImplements.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-lg text-muted-foreground">
                    No implements found matching your criteria. Please try different filters.
                  </p>
                </div>
              )}
            </div>
          </section>

          {/* Benefits Section */}
          <section className="py-16 bg-secondary/30">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Why Choose Our Implements?
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Quality implements that enhance your tractor's performance and farming efficiency
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="text-center p-6">
                  <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Wrench className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Perfect Compatibility</h3>
                  <p className="text-sm text-muted-foreground">
                    All implements tested and compatible with Massey Ferguson tractors
                  </p>
                </Card>
                
                <Card className="text-center p-6">
                  <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Star className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Quality Assured</h3>
                  <p className="text-sm text-muted-foreground">
                    High-quality materials and construction for long-lasting performance
                  </p>
                </Card>
                
                <Card className="text-center p-6">
                  <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Expert Support</h3>
                  <p className="text-sm text-muted-foreground">
                    Professional guidance on selection, installation, and maintenance
                  </p>
                </Card>
              </div>
            </div>
          </section>
        </main>

        <Footer />
        <WhatsAppFloat />
      </div>
    </>
  );
};

export default Implements;